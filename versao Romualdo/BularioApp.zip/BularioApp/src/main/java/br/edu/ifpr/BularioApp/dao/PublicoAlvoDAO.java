package br.edu.ifpr.BularioApp.dao;

import java.util.ArrayList;
import java.util.List;

import br.edu.ifpr.BularioApp.model.PublicoAlvo;
import br.edu.ifpr.BularioApp.model.Remedio;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;

public class PublicoAlvoDAO extends DAO<PublicoAlvo>{

	// PROCURA POR ENTIDADES DE PUBLICOS ALVO QUE POSSUEM RELAÇÃO COM CERTO REMÉDIO
	public List<PublicoAlvo> findByRelationList(Remedio remedio) {
		int idRemedioSelecionado = remedio.getId();
		List<PublicoAlvo> entidadesPublicoAlvo;
		try {
		    Query query = em.createQuery("SELECT pa " + "FROM PublicoAlvo pa, RemediosPublicoAlvo rpa, Remedio r " +  
		    "WHERE rpa.publicoAlvo.id=pa.id AND rpa.remedio.id = :idRemedioSelecionado",PublicoAlvo.class);
		    query.setParameter("idRemedioSelecionado", remedio.getId());
		    entidadesPublicoAlvo = query.getResultList();
		    return entidadesPublicoAlvo;
		}catch (Exception e) {
			e.printStackTrace();
	        return new ArrayList<>();
		}
	}
	
	// PROCURA POR ENTIDADE PUBLICO ALVO COM CERTO NOME
	public PublicoAlvo findByName(String nome) {
		PublicoAlvo entidadePublicoAlvo;
		try {
			TypedQuery<PublicoAlvo> query = em.createQuery("SELECT pa " + "FROM PublicoAlvo pa " + "WHERE pa.nome LIKE :nome", PublicoAlvo.class);
			query.setParameter("nome", "%"+nome+"%");
			entidadePublicoAlvo = query.getSingleResult();
			return entidadePublicoAlvo;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
