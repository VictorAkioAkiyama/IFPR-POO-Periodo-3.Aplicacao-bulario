package br.edu.ifpr.BularioApp.dao;

import br.edu.ifpr.BularioApp.model.Prescricao;

public class PrescricaoDAO extends DAO<Prescricao> {
   
   @Override
   public void save(Prescricao prescricao) {
      try {
           em.getTransaction().begin();
           em.persist(prescricao);
           em.getTransaction().commit();
           System.out.println("Prescricao salvo com sucesso.");
       } catch (Exception e) {
          em.getTransaction().rollback();
          throw new RuntimeException("Erro ao salvar a prescricao", e);
       }
   }
}
