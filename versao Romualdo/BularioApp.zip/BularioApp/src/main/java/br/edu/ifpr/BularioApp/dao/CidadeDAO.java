package br.edu.ifpr.BularioApp.dao;

import br.edu.ifpr.BularioApp.model.Cidade;

public class CidadeDAO extends DAO<Cidade> {

}
