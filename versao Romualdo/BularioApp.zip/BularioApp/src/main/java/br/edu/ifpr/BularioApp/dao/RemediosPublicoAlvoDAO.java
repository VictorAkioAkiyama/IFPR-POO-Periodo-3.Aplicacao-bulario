package br.edu.ifpr.BularioApp.dao;

import br.edu.ifpr.BularioApp.model.RemediosPublicoAlvo;

public class RemediosPublicoAlvoDAO extends DAO<RemediosPublicoAlvo>{
	
	@Override
	public void save(RemediosPublicoAlvo rpa) {
		try {
           em.getTransaction().begin();
           em.persist(rpa);
           em.getTransaction().commit();
           System.out.println("Remedios Publico Alvo salvo com sucesso.");
	    } catch (Exception e) {
	       em.getTransaction().rollback();
	       throw new RuntimeException("Erro ao salvar o Remedios Publico Alvo", e);
	    }
	}
}
